#ifndef _ENCODER_H_
#define _ENCODER_H_
#include "stm32f103.h"

void Encoder_Init(void);


#endif

