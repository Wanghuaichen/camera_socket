
#ifndef _MPU6050_h_
#define _MPU6050_h_


void MPU6050_Config(void);
void MPU6050_DataRecv(char* Rev_Buf,int* counter);
#endif

