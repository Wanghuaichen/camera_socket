#ifndef __CRC_H
#define __CRC_H

#include "stm32f10x.h"

unsigned int CRC16(unsigned char *puchMsg, unsigned int usDataLen);

#endif
