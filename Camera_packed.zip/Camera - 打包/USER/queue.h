#ifndef QUEUE_H
#define QUEUE_H

#include "Var_Def.h"



//PtrToQueue CreateQueue(void);

//int QueueEmpty(PtrToQueue Q);

//void ClearQueue(PtrToQueue Q);

//void EnQueue(PtrToQueue Q,GPS X);

//void DeQueue(PtrToQueue Q);

//int Length(PtrToQueue Q);

//void ListQueue(PtrToQueue);

//void DisposeQueue(PtrToQueue Q);

//GPS ReadQueue(PtrToQueue Q);

#endif // QUEUE_H
