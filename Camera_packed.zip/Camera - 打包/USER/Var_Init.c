#include "Var_Def.h"

//__IO	uint8_t 			UART1_Receive[200]		=	{0};      //RF����

 unsigned int Keyboard_Val =0;




